# Home - OncoFAIR v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://oncofair-ig.kereval.cloud/ImplementationGuide/ltsi.fhir.oncofair | *Version*:0.1.0 |
| Active as of 2025-11-17 | *Computable Name*:OncoFAIR |

 **Description de ce guide d'implémentation**
 Le projet OncoFAIR vise à améliorer l'interopérabilité autour des Entrepôts de Données de Santé sur les données de chimiothérapie pour une réutilisation secondaire des données. OncoFAIR est un projet collaboratif entre l’équipe DOMASIA (DOnnées MAssives et Système d’Information Apprenant en santé) du LTSI (Laboratoire Traitement du Signal et de l'Image) et Kereval, laboratoire d'ingénierie de tests. Ce projet est financé par la Région Bretagne dans le cadre de l’appel à projets « Transfert de technologies des filières santé et biotechnologies 2022 » et reçoit le soutien de Biotech Santé Bretagne. 

### Introduction

The OncoFAIR project is designed to improve the interoperability and reuse of healthcare data in oncology, focusing on chemotherapy. This guide details the use of FHIR standards to optimize prescribing and medication administration for oncology patients.

The production of this implementation guide is based on :

* [Functional specifications](KER3-NOT-BIOTECH_SB_ONCOFAIR-SF-1_02.pdf)
* [Study of norms and standards in the ANS format, justifying the choice of FHIR R5](KER3-NOT-BIOTECH_SB_ONCOFAIR-NS-1_02.pdf)

#### Objectives

* Facilitate access to and exchange of healthcare data in oncology.
* Improve the accuracy and efficiency of patient treatment.
* Contribute to the advancement of clinical research in oncology.

#### Background

Supported by the Brittany Region and Biotech Santé Bretagne, this project benefits from the healthcare data interoperability expertise of the Domasia team at LTSI (Rennes University Hospital) and the Kereval test engineering laboratory.

### Target audience

This guide is intended for developers, healthcare professionals and researchers involved in managing and modeling healthcare data in oncology. It is assumed that the reader is familiar with the FHIR standard.

### Profiled FHIR resources

The following is a list of generic profiles :

# Tableau HL7

| | | |
| :--- | :--- | :--- |
| [CarePlan](https://hl7.org/fhir/R5/careplan.html) | [OncoFAIRCarePlan](StructureDefinition-oncofair-careplan.md) | This object describes the chaining of prescription elements attached to the prescribed protocol. Its structure enables the chaining of nested sub-protocols. |
| [Encounter](https://hl7.org/fhir/R5/encounter.html) | [OncoFAIREncounter](StructureDefinition-oncofair-encounter.md) | Must be taken in the generic sense, i.e. it goes beyond hospital admissions, outpatient consultations, dialysis sessions, day hospitals, etc. |
| [Medication](https://hl7.org/fhir/R5/medication.html) | [OncoFAIRMedication](StructureDefinition-oncofair-medication.md) | TO DO |
| [MedicationAdministration](https://hl7.org/fhir/R5/medicationadministration.html) | [OncoFAIRMedicationAdministrationComponent](StructureDefinition-oncofair-medicationadministration-component.md) | This object corresponds to a product that belongs to the nomenclature of medicines used in the hospital. |
| [MedicationAdministration](https://hl7.org/fhir/R5/medicationadministration.html) | [OncoFAIRMedicationAdministrationElement](StructureDefinition-oncofair-medicationadministration-element.md) | Corresponds to the activity induced by a prescription item and its dosage (structured or unstructured), and carried out at a given moment. |
| [MedicationAdministration](https://hl7.org/fhir/R5/medicationadministration.html) | [OncoFAIRMedicationAdministrationReport](StructureDefinition-oncofair-medicationadministration-report.md) | Regroups all the prescription elements received on which the pharmacist expresses his validation. It also includes items suggested or resulting from a replacement proposed by the pharmacist. |
| [MedicationRequest](https://hl7.org/fhir/R5/medicationrequest.html) | [OncoFAIRMedicationRequestComponent](StructureDefinition-oncofair-medicationrequest-component.md) | Is a product that belongs to the nomenclature of medicines used. It may, for example, be a speciality, a product defined by its common name or a pharmacopoeial product. |
| [MedicationRequest](https://hl7.org/fhir/R5/medicationrequest.html) | [OncoFAIRMedicationRequestElement](StructureDefinition-oncofair-medicationrequest-element.md) | Corresponds to a prescription line on a prescription. Each item contains one or more components (in the case of a magistral preparation or an infusion). |
| [MedicationRequest](https://hl7.org/fhir/R5/medicationrequest.html) | [OncoFAIRMedicationRequestPrescription](StructureDefinition-oncofair-medicationrequest-prescription.md) | Groups together all the prescription elements validated simultaneously by the same prescriber. |
| [Observation](https://hl7.org/fhir/R5/observation.html) | [OncoFAIRObservation](StructureDefinition-oncofair-observation.md) | Allows you to enter information about the patient in addition to that described in the prescription elements. |
| [Patient](https://hl7.org/fhir/R5/patient.html) | [OncoFAIRPatient](StructureDefinition-oncofair-patient.md) | Contains the patient’s identity details needed to ensure that the prescription is properly taken into account. |
| [Clinical Trial](http://hl7.org/fhir/R5/researchstudy.html) | [Oncology Clinical Trial](StructureDefinition-clinical-trial.md) | Oncology clinical trial used to associate a Onco Patient to a Clinical Trial. |
| [Condition](https://hl7.org/fhir/R5/condition.html) | [Tumor Pathology Event](StructureDefinition-dueTo-tumor-pathology-event.md) | Tumor Pathology Event (TPE) Condition describing a tumoral event: reference to the parent TPE, laterality, morphology. |
| [Healthcare Service](http://hl7.org/fhir/R5/healthcareservice.html) | [Oncology Healthcare Service](StructureDefinition-oncology-healthcare-service.md) | Contains the Healthcare Service information. |

### Dependencies



### FHIR interaction

The following interactions can be applied:

* **Search** to search for one or more resources via search parameters. Uses the `HTTP GET` method.
* **Read** to access the current state of the resource. Uses the `HTTP GET` method.
* **Create** method to add a new resource to the server. Uses the `HTTP POST` method.
* **Update** to update an existing resource. Use the `HTTP PUT` method.

